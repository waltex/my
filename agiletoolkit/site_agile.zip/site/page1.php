<?php

include '../vendor/autoload.php';
$app = new App_CLI();
echo "Hello World\n";
